# project/urls.py
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect


urlpatterns = [
    path('', lambda request: redirect('ps:login')),
    path('admin/', admin.site.urls),
    path('', include(('ps.urls', 'ps'), namespace='ps')),
]
