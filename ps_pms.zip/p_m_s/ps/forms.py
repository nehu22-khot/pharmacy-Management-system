from django import forms
from django.contrib.auth import get_user_model
from .models import Assessment, AssessmentName, AssessmentType, ClassMaster, Question, Subject
from django.contrib.auth.forms import UserCreationForm
from django import forms
from .models import AssessmentName
 

CustomUser = get_user_model()

class SimpleStaffForm(UserCreationForm):
    staff_short_name = forms.CharField(max_length=10, required=True)  # Added staff_short_name

    class Meta:
        model = CustomUser
        fields = ['username', 'staff_short_name', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.staff_short_name = self.cleaned_data['staff_short_name']  # Save staff_short_name
        user.raw_password = self.cleaned_data['password1']  # Store plaintext password if needed
        if commit:
            user.save()
        return user
class ClassMasterForm(forms.ModelForm):
    class Meta:
        model = ClassMaster
        fields = "__all__"
        
from ps.models import AssessmentName      

class AssessmentNameForm(forms.ModelForm):
    class Meta:
        model = AssessmentName
        fields = ['academic_year', 'exam_name', 'short_name']  

class AssessmentTypeForm(forms.ModelForm):
    class Meta:
        model = AssessmentType
        fields = ['academic_year', 'assessment_name', 'required_question_paper']

    def save(self, commit=True):
        instance = super().save(commit=False)

        # Get last sequence value for the selected academic year
        last_entry = AssessmentType.objects.filter(
            academic_year=instance.academic_year
        ).order_by('-recid').first()

        if last_entry:
            last_seq = last_entry.sequence.strip().upper()

            if len(last_seq) == 1 and last_seq.isalpha():  # Ensure it's a single alphabet
                instance.sequence = chr(ord(last_seq) + 1) if last_seq < "Z" else "A"
            else:
                instance.sequence = "A"  # Reset sequence if invalid
        else:
            instance.sequence = "A"  # First entry gets "A"

        if commit:
            instance.save()
        return instance
from django import forms
from .models import Assessment
from django import forms
from datetime import timedelta
from .models import Assessment

class AssessmentForm(forms.ModelForm):
    # Allow user to enter duration in minutes
    duration_minutes = forms.IntegerField(label="Duration (minutes)", required=True)

    class Meta:
        model = Assessment
        # Include the fields you want to edit (exclude fields that auto-fill from AssessmentType)
        fields = ['assessment_type', 'assessment_date', 'start_time', 'end_time', 'marks', 'batch', 'code']
        widgets = {
            'assessment_date': forms.DateInput(attrs={'type': 'date'}),
            'start_time': forms.TimeInput(attrs={'type': 'time'}),
            'end_time': forms.TimeInput(attrs={'type': 'time'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        minutes = cleaned_data.get('duration_minutes')
        if minutes is not None:
            cleaned_data['duration'] = timedelta(minutes=minutes)
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        # Set the duration field using the cleaned value from duration_minutes
        instance.duration = self.cleaned_data.get('duration')
        if commit:
            instance.save()
        return instance

from django import forms
from .models import CourseMaster

class CourseMasterForm(forms.ModelForm):
    class Meta:
        model = CourseMaster
        fields = '__all__'

    def clean_course_code(self):
        course_code = self.cleaned_data['course_code']
        if len(course_code) > 20:
            raise forms.ValidationError("Course code cannot exceed 20 characters.")
        return course_code

from .models import CourseOutcome
class CourseOutcomeForm(forms.ModelForm):
    class Meta:
        model = CourseOutcome
        fields = ['course_code', 'co_id', 'statement']
    
from django import forms
from .models import Subject, Question, Assessment

class AttendanceSelectionForm(forms.Form):
    subject = forms.ModelChoiceField(
        queryset=Subject.objects.all(),
        label="Select Subject",
        required=True
    )
    date = forms.DateField(
        widget=forms.DateInput(attrs={"type": "date"}),
        required=True
    )
    time = forms.TimeField(
        widget=forms.TimeInput(attrs={"type": "time"}),
        required=True
    )

class AttendanceForm(forms.Form):
    def __init__(self, *args, **kwargs):
        students = kwargs.pop('students', [])
        super().__init__(*args, **kwargs)
        for student in students:
            self.fields[f"student_{student.id}"] = forms.BooleanField(
                required=False, label=student.name, initial=False
            )

class QuestionForm(forms.ModelForm):
    co_mapped = forms.ChoiceField(
        choices=[("CO-355.1", "CO-355.1"), ("CO-355.2", "CO-355.2")],
        widget=forms.Select(attrs={"class": "form-control"})
    )
    po_mapped = forms.ChoiceField(
        choices=[("PO1", "PO1"), ("PO2", "PO2"), ("PO3", "PO3"), ("PO9", "PO9")],
        widget=forms.Select(attrs={"class": "form-control"})
    )

    class Meta:
        model = Question
        fields = "__all__"
        widgets = {
            "question_no": forms.NumberInput(attrs={"class": "form-control"}),
            "sub_question_no": forms.TextInput(attrs={"class": "form-control"}),
            "question_title": forms.TextInput(attrs={"class": "form-control"}),
            "question_text": forms.Textarea(attrs={"class": "form-control"}),
            "marks": forms.NumberInput(attrs={"class": "form-control"}),
            "que_tag": forms.Select(attrs={"class": "form-control"}),
            "attempt_any": forms.NumberInput(attrs={"class": "form-control"}),
        }





