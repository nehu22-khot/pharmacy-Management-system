from django.contrib.auth.models import AbstractUser, UserManager
from django.db import models

# ---------------------------
# 1. AcademicYear
# ---------------------------
class AcademicYear(models.Model):
    academic_year = models.CharField(max_length=100, default='2024-2025')

    def __str__(self):
        return self.academic_year


# ---------------------------
# 2. Custom User
# ---------------------------
class CustomUserManager(UserManager):
    pass

class CustomUser(AbstractUser):
    ACADEMIC_YEAR_CHOICES = [
        ('2024-2025', '2024-2025'),
        ('2025-2026', '2025-2026'),
        ('2026-2027', '2026-2027'),
    ]

    USER_TYPE_CHOICES = (
        ('admin', 'Admin'),
        ('staff', 'Staff'),
    )

    user_type = models.CharField(max_length=100, choices=USER_TYPE_CHOICES, default='staff')
    staff_short_name = models.CharField(max_length=50, blank=True, null=True)
    raw_password = models.CharField(max_length=128, blank=True, null=True)  # Plaintext password (insecure)
    academic_year = models.CharField(
        max_length=10,
        choices=ACADEMIC_YEAR_CHOICES,
        default='2024-2025'
    )

    objects = CustomUserManager()

    def save(self, *args, **kwargs):
        # Hash the raw_password if provided
        if self.raw_password:
            self.set_password(self.raw_password)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.username

    class Meta:
        db_table = 'customuser'


# ---------------------------
# 3. Course, Year, Semester, CourseType
# ---------------------------
class Course(models.Model):
    recid = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    # ... other fields if needed ...

    def __str__(self):
        return self.name

class Year(models.Model):
    recid = models.AutoField(primary_key=True, db_column='id')
    year = models.CharField(max_length=10)
    
    def __str__(self):
        return self.year

class Semester(models.Model):
    recid = models.AutoField(primary_key=True, db_column='id')
    semester = models.CharField(max_length=10)
    code = models.CharField(max_length=20, unique=True)
    # ... other fields if needed ...

    def __str__(self):
        return self.semester

class CourseType(models.Model):
    recid = models.AutoField(primary_key=True, db_column='id')
    name = models.CharField(max_length=50)
    # ... other fields if needed ...

    def __str__(self):
        return self.name


# ---------------------------
# 4. Subject Model
# ---------------------------
from django.db import models

class Subject(models.Model):
    TYPE_CHOICES = [
        ('Theory', 'Theory'),
        ('Practical', 'Practical'),
    ]
    recid = models.AutoField(primary_key=True)
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='Theory')
    year = models.CharField(max_length=50)
    course = models.CharField(max_length=100)
    semester = models.CharField(max_length=10)
    code = models.CharField(max_length=20, unique=True)  # Use unique=True instead of primary_key
    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return f"{self.name} ({self.code})"

    class Meta:
        ordering = ["semester", "code"]
        verbose_name = "Subject"
        verbose_name_plural = "Subjects"


# ---------------------------
# 5. Pattern Model
# ---------------------------
class Pattern(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


# ---------------------------
# 6. ClassMaster Model
# ---------------------------
class ClassMaster(models.Model):
    YEAR_CHOICES = [
        ('First Year', 'First Year'),
        ('Second Year', 'Second Year'),
        ('Third Year', 'Third Year'),
        ('Fourth Year', 'Fourth Year'),
    ]

    rec_id = models.AutoField(primary_key=True)
    academic_year = models.ForeignKey(AcademicYear, on_delete=models.SET_NULL, null=True)
    course = models.CharField(max_length=100)
    year = models.CharField(max_length=50)  # from YEAR_CHOICES or other sources
    semester = models.CharField(max_length=10)
    pattern_name = models.ForeignKey(Pattern, on_delete=models.SET_NULL, null=True, blank=True)
    patternN = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f"{self.academic_year} - {self.course}"

    class Meta:
        db_table = "pharmacy_classmaster"


# ---------------------------
# 7. AssessmentName & AssessmentType
# ---------------------------
class AssessmentName(models.Model):
    recid = models.AutoField(primary_key=True)
    academic_year = models.CharField(max_length=100)
    exam_name = models.CharField(max_length=100)
    short_name = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.exam_name} ({self.short_name})"

    class Meta:
        db_table = 'ps_assessmentname'


class AssessmentType(models.Model):
    recid = models.BigAutoField(primary_key=True)
    academic_year = models.CharField(max_length=11)  # Academic Year as a text field allowing "2025 to 2026"
    assessment_name = models.ForeignKey(AssessmentName, on_delete=models.CASCADE)
    required_question_paper = models.CharField(
        max_length=3,
        choices=[("Yes", "Yes"), ("No", "No")],
        default="No"
    )
    sequence = models.CharField(max_length=20)
    added_by = models.CharField(max_length=10, default="Admin", editable=False)  # Fixed "Added by" field with default value as "Admin"

    def __str__(self):
        return f"{self.academic_year} - {self.assessment_name.exam_name} ({self.assessment_name.short_name})"

    class Meta:
        db_table = 'ps_assessmenttype'
        ordering = ['sequence']
        unique_together = ('academic_year', 'assessment_name')
        verbose_name = "Assessment Type"


# ---------------------------
# 8. CourseMaster Model
# ---------------------------
from django.db import models


class CourseMaster(models.Model):
    recid = models.AutoField(primary_key=True)
    academic_year = models.CharField(max_length=10, default="2025")
    course = models.ForeignKey("Course", on_delete=models.CASCADE)
    subject = models.ForeignKey("Subject", on_delete=models.CASCADE, blank=True, null=True)
    year = models.ForeignKey("Year", on_delete=models.CASCADE)
    semester = models.ForeignKey("Semester", on_delete=models.CASCADE)
    course_type = models.CharField(max_length=20, choices=[("Theory", "Theory"), ("Practical", "Practical")])

    COURSE_OPTION_CHOICES = [
        ("Compulsory", "Compulsory"),
        ("Elective", "Elective"),
    ]
    course_option = models.CharField(max_length=20, choices=COURSE_OPTION_CHOICES, default="Compulsory")

    course_code = models.CharField(max_length=20, unique=True)

    internal_exam_marks = models.IntegerField(default=0)
    end_exam_marks = models.IntegerField(default=0)
    activities = models.IntegerField(default=0)
    max_marks = models.IntegerField(default=0)
    co_attainment_activities = models.IntegerField(default=0)

    CALCULATION_MODE_CHOICES = [
        ("Average", "Average"),
        ("Best of", "Best of"),
    ]
    calculation_mode = models.CharField(max_length=20, choices=CALCULATION_MODE_CHOICES, default="Average")

    computation_marks = models.IntegerField(default=0)
    co_marks = models.IntegerField(default=0)

    BASELINE_MARKS_CHOICES = [
        ("Low", "Low"),
        ("Medium", "Medium"),
        ("High", "High"),
    ]
    base_line_marks = models.CharField(max_length=10, choices=BASELINE_MARKS_CHOICES, default="Medium")

    ROUND_UP_CHOICES = [
        ("Yes", "Yes"),
        ("No", "No"),
    ]
    round_up = models.CharField(max_length=3, choices=ROUND_UP_CHOICES, default="No")

    class Meta:
        ordering = ["academic_year", "course", "semester"]
        verbose_name = "Course Master"
        verbose_name_plural = "Course Masters"

    def save(self, *args, **kwargs):
        """
        Automatically creates and assigns a Subject if the `subject_text` attribute is provided.
        Ensures subject integrity before saving the CourseMaster instance.
        """
        if hasattr(self, "subject_text") and self.subject_text and not self.subject:
            self.subject, created = Subject.objects.get_or_create(
                name=self.subject_text,
                defaults={
                    "type": str(self.type),
                    "year": str(self.year.year),
                    "course": str(self.course.name),
                    "semester": str(self.semester.semester),
                    "code": self.course_code,
                },
            )
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.course.name} - {self.subject.name} ({self.academic_year})"



from django.db import models
from django.contrib.auth import get_user_model

CustomUser = get_user_model()  # Ensure compatibility with custom user models

class FacultyCourseAllocation(models.Model):
    faculty = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        limit_choices_to={'user_type': 'staff', 'is_active': True},  # Filter active staff only
        related_name="allocated_courses"
    )

    subject = models.ForeignKey(
        Subject,
        on_delete=models.CASCADE,
        related_name="allocated_faculty"
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['faculty', 'subject'],
                name="unique_faculty_subject"
            )
        ]
        verbose_name = "Faculty Course Allocation"
        verbose_name_plural = "Faculty Course Allocations"

    def __str__(self):
        faculty_name = self.faculty.get_full_name() or self.faculty.username  # Fallback to username
        return f"{faculty_name} - {self.subject.name} ({self.subject.code})"


# ---------------------------
# 9. StudentExamInfo Model
# ---------------------------
class StudentExamInfo(models.Model):
    Course = models.ForeignKey(Course, on_delete=models.CASCADE)
    Year = models.ForeignKey(Year, on_delete=models.CASCADE)
    reg_id = models.CharField(max_length=10, unique=True)
    student_name = models.CharField(max_length=255)
    odd_roll_no = models.IntegerField()
    odd_exam_no = models.CharField(max_length=10)
    odd_batch = models.CharField(max_length=1)
    even_roll_no = models.IntegerField()
    even_exam_no = models.CharField(max_length=10)
    even_batch = models.CharField(max_length=1)

    def __str__(self):
        return f"{self.reg_id} - {self.student_name}"


# ---------------------------
# 10. CourseOutcome & COPO_Mapping
# ---------------------------

class CO(models.Model):
    code = models.CharField(max_length=20, unique=True)

    class Meta:
        db_table = "co"
        
class PO(models.Model):
    po_no = models.CharField(max_length=20, unique=True)

    class Meta:
        db_table = "po"
from django.db import models

class CourseOutcome(models.Model):
    course_code = models.ForeignKey(
        'Subject',  
        related_name='course_code_outcomes',
        on_delete=models.CASCADE)
    co_id = models.CharField(max_length=50, unique=True) 

    statement = models.TextField()

    def __str__(self):
        return f"{self.co_id} - {self.statement}"
    class Meta:
        db_table = 'course_outcome'

class COPO_Mapping(models.Model):
    PO_LEVEL_CHOICES = [
        ('High', 'High'),
        ('Medium', 'Medium'),
        ('Low', 'Low'),
        ('-', '-')  # Add '-' as a valid choice if needed.
    ]
    
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name="copo_mappings")
    co_number = models.ForeignKey(CourseOutcome, on_delete=models.CASCADE, related_name="copo_mappings")  # ✅ FIXED ForeignKey

    po1 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po1")
    po2 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po2")
    po3 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po3")
    po4 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po4")
    po5 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po5")
    po6 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po6")
    po7 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po7")
    po8 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po8")
    po9 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po9")
    po10 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po10")
    po11 = models.ForeignKey(PO, on_delete=models.SET_NULL, null=True, blank=True, related_name="copo_mapping_po11")

    def __str__(self):
        return f"{self.subject.name} - {self.co_number.co_id}"  # ✅ FIXED

    class Meta:
        db_table = "COPO_Mapping"
        ordering = ["subject", "co_number"]
        indexes = [
            models.Index(fields=["subject"]),
            models.Index(fields=["co_number"]),  # ✅ FIXED as a ForeignKey field
        ]
        
class Instruction(models.Model):
    text = models.TextField()

    def __str__(self):
        return self.text[:50]

    class Meta:
        db_table = 'instruction'


# ---------------------------
# 12. Assessment Model
# ---------------------------
class Assessment(models.Model):
    assessment_type = models.ForeignKey(AssessmentType, on_delete=models.CASCADE)  # Linked to AssessmentType
    recid = models.IntegerField() 
    short_name = models.CharField(max_length=100, blank=True, null=True)  
    required_question_paper = models.CharField(max_length=3, blank=True, null=True)  # From AssessmentType
    sequence = models.CharField(max_length=20, blank=True, null=True)  # From AssessmentType

    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, null=True, blank=True) 
    assessment_date = models.DateField()  
    batch = models.CharField(max_length=20)  
    duration = models.DurationField()  
    start_time = models.TimeField()  
    end_time = models.TimeField()  
    marks = models.IntegerField(null=True, blank=True)  
    code=models.IntegerField(null=True, blank=True)  

    que_paper_status = models.CharField(
        max_length=50, choices=[("Complete", "Complete"), ("Incomplete", "Incomplete")], default="Incomplete"
    )
    mark_entry_status = models.CharField(
        max_length=50, choices=[("Complete", "Complete"), ("Incomplete", "Incomplete")], default="Incomplete"
    )

    def save(self, *args, **kwargs):
        """Auto-fill fields from AssessmentType before saving"""
        if self.assessment_type:
            self.recid = self.assessment_type.recid  # recid from AssessmentType
            self.short_name = self.assessment_type.assessment_name.short_name  # short_name from AssessmentName
            self.required_question_paper = self.assessment_type.required_question_paper  # required_question_paper from AssessmentType
            self.sequence = self.assessment_type.sequence  # sequence from AssessmentType
        super().save(*args, **kwargs)  

    def __str__(self):
        return f"{self.short_name} ({self.assessment_type})"

    class Meta:
        db_table = "ps_assessment"
        ordering = ["recid"]






# ---------------------------
# 13. Student Model
# ---------------------------

class Student(models.Model):
    reg_id = models.IntegerField()
    prn = models.CharField(max_length=20, unique=True)
    roll_no = models.CharField(max_length=10)
    name = models.CharField(max_length=255)
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE)
    attended = models.BooleanField(default=True)
    seat_no = models.CharField(max_length=10, unique=True)
    total_marks = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.name} ({self.roll_no})"

    class Meta:
        db_table = 'student'


# ---------------------------
# 14. Attendance Model
# ---------------------------
class Attendance(models.Model):
    CLASS_ATTENDANCE = 'class'
    EXAM_ATTENDANCE = 'exam'

    ATTENDANCE_TYPE_CHOICES = [
        (CLASS_ATTENDANCE, 'Class Attendance'),
        (EXAM_ATTENDANCE, 'Exam Attendance'),
    ]

    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, null=True, blank=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE, null=True, blank=True)
    is_present = models.BooleanField(default=False)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    attendance_type = models.CharField(
        max_length=10,
        choices=ATTENDANCE_TYPE_CHOICES,
        default=CLASS_ATTENDANCE
    )

    class Meta:
        db_table = 'attendance'
        unique_together = ('student', 'assessment', 'date', 'time')

    def _str_(self):
        return f"{self.student} - {self.date} - {self.time} - {self.attendance_type}"


# ---------------------------
# 15. Question Model
# ---------------------------
class Question(models.Model):
   
    assessment_type = models.ForeignKey(AssessmentType, on_delete=models.CASCADE)
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    
    QUE_TAG_CHOICES = [
        ('Solve any Three', 'Solve any Three'),
        ('Solve any Two', 'Solve any Two'),
        ('Solve any One', 'Solve any One'),
    ]
    
    question_id = models.CharField(max_length=100)
    section = models.CharField(max_length=100, blank=True, null=True)
    que_tag = models.CharField(max_length=50, choices=QUE_TAG_CHOICES)
    sub_que_no = models.CharField(max_length=10)
    quiz_no = models.IntegerField()
    question_title = models.CharField(max_length=255)
    question_text = models.TextField()
    marks = models.IntegerField()
    attempt_any = models.IntegerField()
    co = models.ForeignKey(CO, on_delete=models.CASCADE)
    po = models.ForeignKey(PO, on_delete=models.CASCADE)  

def __str__(self):
    return f"{self.assessment_type.name.upper()} - {self.sub_que_no}: {self.question_text[:50]}..."

class SubQuestion(models.Model):
    question = models.ForeignKey(Question, related_name="subquestions", on_delete=models.CASCADE)
    sub_que_no = models.CharField(max_length=10)  # For example "a)", "b)", etc.
    subquestion_text = models.TextField()         # The text for that part
    sub_marks = models.IntegerField(blank=True, null=True)  # Marks for this part

    def __str__(self):
        return f"{self.sub_que_no} {self.subquestion_text[:50]}"

# ---------------------------
# 16. MarkEntry Model
# --------------------------

class MarkEntry(models.Model):
    exam_type = models.CharField(max_length=10, default='Internal')  # Fixed missing default
    obtained_marks = models.IntegerField(null=True, blank=True)  # Allows NULL values
    assessment = models.ForeignKey('Assessment', on_delete=models.CASCADE)  # Foreign key to Assessment
    question = models.ForeignKey('Question', on_delete=models.CASCADE)  # Foreign key to Question
    student = models.ForeignKey('Student', on_delete=models.CASCADE)  # Foreign key to Student
    subject = models.ForeignKey('Subject', on_delete=models.CASCADE)  # Foreign key to Subject
    assessment_type_id = models.BigIntegerField(null=True, blank=True)  # Allows NULL values

    def __str__(self):
        return f"{self.student} - {self.subject} - {self.exam_type}"


class QuestionPaper(models.Model):
    # Que ID: a unique identifier for each question.
    q_id = models.CharField(max_length=50, unique=True)
    # Question Bank - Question: the actual question text.
    text = models.TextField()
    # Marks: the marks assigned for the question.
    question_marks = models.IntegerField()
    # CO Mapped: a text field to store the mapped CO (or you can later change to a ForeignKey if you create a CO model).
    co_mapped = models.CharField(max_length=50)
    # PO Mapped: a text field to store the mapped PO.
    po_mapped = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.question_id} - {self.question_text[:30]}"
