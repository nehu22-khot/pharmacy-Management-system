from django.urls import path
from . import views

app_name = "ps"

urlpatterns = [
    path('login/', views.user_login, name='login'),
    path('add-staff/', views.add_staff, name='addstaff'),
    path('staffdashboard/', views.staff_dashboard_view, name='staffdashboard'),
    path('select-subject/', views.select_subject, name='select_subject'),
    path('admin-dashboard/', views.admin_dashboard, name='admindashboard'),
    path('class-master/', views.class_master, name='class_master'),
    path("assessment-master/", views.assessment_type_master, name="assessment_type_master"),
    path('assessment_master_name/', views.assessment_master_name, name='assessment_master_name'),
    path('course-master/', views.course_master, name='course_master'),
    path('roll-update',views.roll_update,name='roll_update'),

    path('logout/', views.user_logout, name='logout'),
    


    path('co-statement/', views.co_statement, name='co_statement'),
    path("co-po-mapping/", views.co_po_mapping, name="co_po_mapping"),
    path("assessment/", views.assessment_view, name="assessment"),
    path('attendance/', views.class_attendance, name='attendance'),
    path('save-attendance/', views.save_attendance, name='save_attendance'),
    path("update_attendance/", views.update_attendance, name="update_attendance"),
    path("attendance_report/", views.attendance_report, name="attendance_report"),   
    path('mark-entry/', views.mark_entry, name='mark_entry'),
    path('mark-entry/<int:recid>/', views.mark_entry, name='merged_mark_entry'),
     path('course_marks/', views.course_marks, name='course_marks'),
     path('co-tools/', views.co_tools, name='co_tools'),
     path('co-attainment/', views.co_attainment_analysis, name='co_attainment_analysis'),
      path('course-summary/', views.course_summary, name='course_summary'),
     path('print-preview/', views.print_preview, name='print_preview'),
    path('question-paper/<int:assessment_id>/', views.question_paper, name='question_paper'),
      path('print-preview/', views.print_preview_view, name='print_preview_view'),
      path('staff-allotment/', views.staff_allotment, name='staff_allotment'),
    
]  
