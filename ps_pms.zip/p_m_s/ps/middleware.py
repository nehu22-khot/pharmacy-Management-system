from django.http import HttpResponseForbidden

def admin_restriction(get_response):
    def middleware(request):
        if request.path.startswith('/admin/') and not request.user.is_superuser:
            return HttpResponseForbidden("You are not allowed to access this page.")
        return get_response(request)
    return middleware
