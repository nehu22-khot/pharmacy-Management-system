from dis import Instruction
from django.contrib import admin
from .models import CO, PO, Attendance, Course,Assessment, MarkEntry, Question, Student, Year, Semester, CourseType, CourseMaster, Subject, COPO_Mapping, Pattern, ClassMaster, AssessmentName, AssessmentType

admin.site.register(Course)
admin.site.register(Year)
admin.site.register(Semester)
admin.site.register(CourseType)
admin.site.register(CourseMaster)
admin.site.register(Subject)
admin.site.register(COPO_Mapping)

admin.site.register(Pattern)
admin.site.register(ClassMaster)
admin.site.register(AssessmentName)
admin.site.register(AssessmentType)
admin.site.register(CO)
admin.site.register(PO)
admin.site.register(Assessment)




from django.contrib import admin
from .models import AcademicYear

admin.site.register(AcademicYear)
from django.contrib import admin
from .models import Instruction, Assessment, Student, Attendance, Question, MarkEntry

@admin.register(Instruction)
class InstructionAdmin(admin.ModelAdmin):
    list_display = ('text',)
    search_fields = ('text',)


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('name', 'roll_no', 'prn', 'seat_no', 'total_marks', 'attended')
    search_fields = ('name', 'roll_no', 'prn', 'seat_no')
    list_filter = ('attended',)

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('student', 'date', 'time', 'attendance_type', 'is_present')
    list_filter = ('attendance_type', 'is_present', 'date')
    search_fields = ('student__name', 'student__roll_no', 'date')

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = (
        'id', 
        'assessment', 
        'subject', 
        'que_tag', 
        'sub_que_no', 
        'quiz_no', 
        'question_title', 
        'marks', 
        'attempt_any', 
        'assessment_type'
    )
    list_filter = ('assessment', 'subject', 'assessment_type', 'que_tag')
    search_fields = ('question_title', 'question_text', 'sub_que_no')
    ordering = ('quiz_no',)




