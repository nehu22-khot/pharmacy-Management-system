from dis import Instruction
from http.client import HTTPResponse
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, logout, login as auth_login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from .forms import    QuestionForm,  SimpleStaffForm  # Use SimpleStaffForm here
from django.contrib.auth.decorators import login_required, user_passes_test  # Add user_passes_test here
from ps.models import Instruction
from django.shortcuts import render
from .forms import AssessmentNameForm


CustomUser = get_user_model()

def is_admin(user):
    return user.is_superuser  # Only superusers can access this view

@user_passes_test(is_admin)
def add_staff(request):
    # Check if the request is for deletion
    if request.method == 'POST' and 'delete_user' in request.POST:
        user_id = request.POST.get('user_id')
        user = get_object_or_404(CustomUser, id=user_id)
        if user.is_superuser:
            messages.error(request, "Cannot delete an admin user.")
        else:
            user.delete()
            messages.success(request, f"User {user.username} deleted successfully.")
        return redirect('ps:addstaff')
    
    # Otherwise, handle add staff form submission
    if request.method == 'POST':
        form = SimpleStaffForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Staff account created successfully.")
            return redirect('ps:addstaff')
        else:
            messages.error(request, f"Error: {form.errors}")
    else:
        form = SimpleStaffForm()

    # Fetch non-admin users using filter()
    staff_list = CustomUser.objects.filter(is_superuser=False)
    
    return render(request, 'addstaff.html', {
        'form': form,
        'staff_list': staff_list,
    })


from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.shortcuts import render, redirect
from .models import AcademicYear, CourseOutcome

def user_login(request):
    if request.method == "POST":
        # Get the user type from the form; default to "admin"
        user_type = request.POST.get("user_type", "admin")
        username = request.POST.get("username")
        password = request.POST.get("password")
        
        # For staff login, expect an academic year from the dropdown; for admin, ignore it.
        academic_year = request.POST.get("academic_year") if user_type == "staff" else None

        # Authenticate user with provided credentials
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            # For staff (non-superuser) ensure academic year is provided.
            if user.is_staff and not user.is_superuser:
                if academic_year:
                    request.session['academic_year'] = academic_year
                else:
                    messages.error(request, "Academic year is required for staff login.")
                    return redirect("ps:login")
            # Redirect based on user type:
            if user.is_superuser:
                return redirect("ps:admindashboard")
            elif user.is_staff:
                return redirect("ps:staffdashboard")
            else:
                return redirect("ps:staffdashboard")
        else:
            messages.error(request, "Invalid username or password")
            return redirect("ps:login")
    
    # For GET request, query all academic years and pass them to the template.
    academic_years = AcademicYear.objects.all()
    return render(request, 'login.html', {'academic_years': academic_years})






@login_required
def admin_dashboard(request):
    if request.method == 'POST':
        form = SimpleStaffForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_staff = True
            user.save()
            messages.success(request, "Staff account created successfully.")
            return redirect("ps:admindashboard")
    else:
        form = SimpleStaffForm()

    return render(request, 'admin_dashboard.html', {'form': form})



from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Subject  # Ensure Subject model is imported

@login_required
def staff_dashboard_view(request):
    academic_year = request.session.get('academic_year', 'Not Selected')
    semester_filter = request.GET.get('semester', 'all')
    selected_subject_id = request.GET.get('subject_id')  # Get selected subject from request

    semesters = {
        'odd': ['I', 'III', 'V', 'VII'], 
        'even': ['II', 'IV', 'VI', 'VIII']
    }

    # Filter subjects based on semester selection
    subjects = Subject.objects.filter(
        semester__in=semesters.get(semester_filter, Subject.objects.values_list('semester', flat=True))
    )

    # Get the selected subject object
    selected_subject = None
    if selected_subject_id:
        selected_subject = subjects.filter(id=selected_subject_id).first()

    context = {
        'user_name': request.user.get_full_name() or request.user.username,
        'academic_year': academic_year,
        'subjects': subjects,
        'semester_filter': semester_filter,
        'selected_subject': selected_subject,
    }
    return render(request, 'staffdashboard.html', context)


from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Subject

def select_subject(request):
    if request.method == "POST":
        subject_id = request.POST.get("subject_id")

        if not subject_id:
            return JsonResponse({"success": False, "error": "No subject ID received by the server."})

        try:
            subject = get_object_or_404(Subject, recid=subject_id)  # Use recid in the query
            
            # Store the selected subject in the session
            request.session['selected_subject_id'] = subject_id

            return JsonResponse({"success": True, "subject_name": str(subject)})

        except Subject.DoesNotExist:
            return JsonResponse({"success": False, "error": "Subject not found."})

    return JsonResponse({"success": False, "error": "Invalid request method"})

from django.shortcuts import get_object_or_404, render, redirect
from django.contrib import messages
from .models import AcademicYear, ClassMaster, Pattern

def class_master(request):
    if request.method == "POST":
        action = request.POST.get("action")
        rec_id = request.POST.get("class_master_id")
        
        # Retrieve text inputs from the form
        academic_year_input = request.POST.get("academic_year")
        year_value = request.POST.get("year")
        semester_value = request.POST.get("semester")
        pattern_input = request.POST.get("pattern")
        patternN = request.POST.get("patternN")
        
        # Since academic_year is now a text field, try to fetch or create the object.
        if academic_year_input:
            academic_year_obj, created = AcademicYear.objects.get_or_create(
                academic_year=academic_year_input
            )
        else:
            academic_year_obj = None
        
        # The course is fixed to "B.Pharmacy"
        course = "B.Pharmacy"
        
        # For pattern, assuming the Pattern model has a 'name' field.
        if pattern_input:
            pattern_obj, created = Pattern.objects.get_or_create(
                name=pattern_input
            )
        else:
            pattern_obj = None

        if action == "save":
            if rec_id:
                # Update an existing record.
                record = get_object_or_404(ClassMaster, pk=rec_id)
                record.academic_year = academic_year_obj
                record.course = course
                record.year = year_value
                record.semester = semester_value
                record.pattern_name = pattern_obj
                record.patternN = patternN
                record.save()
                messages.success(request, "Record updated successfully.")
            else:
                # Create a new record.
                ClassMaster.objects.create(
                    academic_year=academic_year_obj,
                    course=course,
                    year=year_value,
                    semester=semester_value,
                    pattern_name=pattern_obj,
                    patternN=patternN,
                )
                messages.success(request, "Record created successfully.")
            return redirect("ps:class_master")
        
        elif action == "delete":
            if rec_id:
                record = get_object_or_404(ClassMaster, pk=rec_id)
                record.delete()
                messages.success(request, "Record deleted successfully.")
            else:
                messages.error(request, "No record selected for deletion.")
            return redirect("ps:class_master")
    
    # For GET requests:
    academic_years = AcademicYear.objects.all().order_by("academic_year")
    
    # Fixed course value: "B.Pharmacy"
    courses = [{"pk": "B.Pharmacy", "name": "B.Pharmacy"}]
    
    # Use the defined YEAR_CHOICES from ClassMaster model
    year_choices = ClassMaster.YEAR_CHOICES
    
    # Default semester choices from 1 to 8
    semesters = [
        ("1", "I"),
        ("2", "II"),
        ("3", "III"),
        ("4", "IV"),
        ("5", "V"),
        ("6", "VI"),
        ("7", "VII"),
        ("8", "VIII")
    ]
    
    patterns = Pattern.objects.all()
    class_master_records = ClassMaster.objects.all()
    
    context = {
        "academic_years": academic_years,
        "courses": courses,
        "year_choices": year_choices,
        "semesters": semesters,
        "patterns": patterns,
        "class_master": class_master_records,
    }
    
    return render(request, "class_master.html", context)
import re
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse
from .models import AssessmentName, AssessmentType

def assessment_type_master(request):
    # Check if this is an AJAX GET request for the short name
    if request.method == "GET" and request.headers.get("x-requested-with") == "XMLHttpRequest":
        recid = request.GET.get("recid")
        if recid:
            assessment_name = get_object_or_404(AssessmentName, recid=recid)
            return JsonResponse({"short_name": assessment_name.short_name})
        return JsonResponse({"short_name": ""})
    
    # Get data for dropdown and display table
    assessment_names = AssessmentName.objects.all()
    assessments = AssessmentType.objects.all()
    
    if request.method == "POST":
        action = request.POST.get("action", "create")  # "create", "edit", or "delete"
        
        # Delete action
        if action == "delete":
            recid = request.POST.get("recid")
            if recid:
                assessment = get_object_or_404(AssessmentType, recid=recid)
                assessment.delete()
                messages.success(request, "Assessment Type deleted successfully!")
            else:
                messages.error(request, "No record specified to delete.")
            return redirect("ps:assessment_type_master")
        
        # For create and edit, common fields:
        academic_year = request.POST.get("academic_year", "").strip()
        assessment_name_id = request.POST.get("assessment_name")
    
        required_question_paper = request.POST.get("required_question_paper", "No")
        sequence = request.POST.get("sequence", "").strip()
        
        # Validate required fields
        if not academic_year or not assessment_name_id or not sequence:
            messages.error(request, "All fields are required!")
            return redirect("ps:assessment_type_master")
        
        # Validate academic year format (YYYY-YYYY)
        match = re.match(r"^(\d{4})-(\d{4})$", academic_year)
        if not match:
            messages.error(request, "Invalid academic year format. Use 'YYYY-YYYY'.")
            return redirect("ps:assessment_type_master")
        start_year, end_year = int(match.group(1)), int(match.group(2))
        if start_year >= end_year:
            messages.error(request, "The first year must be smaller than the second year.")
            return redirect("ps:assessment_type_master")
        
        # Fetch the related AssessmentName record
        assessment_name = get_object_or_404(AssessmentName, recid=assessment_name_id)
        
        if action == "edit":
            recid = request.POST.get("recid")
            if not recid:
                messages.error(request, "No record specified for editing.")
                return redirect("ps:assessment_type_master")
            assessment = get_object_or_404(AssessmentType, recid=recid)
            assessment.academic_year = academic_year
            assessment.assessment_name = assessment_name
            assessment.required_question_paper = required_question_paper
            assessment.sequence = sequence
            assessment.save()
            messages.success(request, "Assessment Type updated successfully!")
        else:  # action == "create"
            AssessmentType.objects.create(
                academic_year=academic_year,
                assessment_name=assessment_name,
                required_question_paper=required_question_paper,
                sequence=sequence
            )
            messages.success(request, "Assessment Type saved successfully!")
        return redirect("ps:assessment_type_master")
    
    return render(request, "assessment_master_type.html", {
        "assessment_names": assessment_names,
        "assessments": assessments,
    })




from django.shortcuts import render, get_object_or_404, redirect
from .models import AssessmentName
from .forms import AssessmentNameForm

def assessment_master_name(request):
    assessments = AssessmentName.objects.all()
    editing_assessment = None
    form = AssessmentNameForm()  # Initialize an empty form

    if request.method == "POST":
        print("POST DATA:", request.POST)  # Debug print

        action = request.POST.get("action")
        if action == "delete":
            assessment_id = request.POST.get("assessment_id")
            assessment = get_object_or_404(AssessmentName, recid=assessment_id)
            assessment.delete()
            return redirect('ps:assessment_master_name')
        
        # Handle save (create or update)
        assessment_id = request.POST.get("assessment_id")
        if assessment_id:  # Editing an existing record
            instance = get_object_or_404(AssessmentName, recid=assessment_id)
            form = AssessmentNameForm(request.POST, instance=instance)
        else:  # Creating a new record
            form = AssessmentNameForm(request.POST)
        
        print("Form is valid:", form.is_valid())  # Debug: Check if form is valid
        print("Form errors:", form.errors)  # Debug: Print form errors

        if form.is_valid():
            # The form should include an academic_year field, which will be filled in by the user.
            assessment = form.save()
            return redirect('ps:assessment_master_name')
        # If the form is not valid, the view will fall through to re-render the template with error messages.
    
    else:
        # GET request: Check if the user wants to edit an existing record.
        if request.GET.get("action") == "edit":
            assessment_id = request.GET.get("assessment_id")
            if assessment_id:
                editing_assessment = get_object_or_404(AssessmentName, recid=assessment_id)
                form = AssessmentNameForm(instance=editing_assessment)

    context = {
        'assessments': assessments,
        'form': form,
        'editing_assessment': editing_assessment,
    }
    return render(request, 'assessment_master_name.html', context)


from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import CourseMaster, Course, Year, Semester, CourseType, AssessmentName, Subject

def course_master(request):
    assessments = AssessmentName.objects.all()
    course_master_list = CourseMaster.objects.all()

    # Get all existing course types from the database
    course_types = CourseType.objects.values_list("name", flat=True)

    if request.method == "POST":
        action = request.POST.get("action")
        record_recid = request.POST.get("record_recid", "").strip()

        if action in ["Edit", "Delete"]:
            if not record_recid.isdigit():
                messages.error(request, "Invalid record ID! Please select a valid record.")
                return redirect("ps:course_master")
            record_recid = int(record_recid)

        # Retrieve form inputs
        course_input = request.POST.get("course", "").strip()
        subject_input = request.POST.get("subject", "").strip()
        year_input = request.POST.get("year", "").strip()
        semester_input = request.POST.get("semester", "").strip()
        coursetype_input = request.POST.get("coursetype", "").strip()

        # Ensure that the user provided a course type
        if not coursetype_input:
            messages.error(request, "Course type is required!")
            return redirect("ps:course_master")

        # Get or create the CourseType entry
        coursetype_obj, created = CourseType.objects.get_or_create(name=coursetype_input)

        academic_year = request.POST.get("academic_year", "2025").strip()
        course_option = request.POST.get("course_option", "").strip()
        course_code = request.POST.get("course_code", "").strip()
        base_line_marks = request.POST.get("base_line_marks", "").strip()
        round_up = request.POST.get("round_up", "").strip()

        # Validate numeric fields
        def get_int_value(field_name, default=0):
            value = request.POST.get(field_name, "").strip()
            return int(value) if value.isdigit() else default

        internal_exam_marks = get_int_value("internal_exam_marks")
        end_exam_marks = get_int_value("end_exam_marks")
        activities = get_int_value("activities")
        max_marks = get_int_value("max_marks")
        co_attainment_activities = get_int_value("co_attainment_activities")

        if not all([course_input, subject_input, year_input, semester_input]):
            messages.error(request, "All fields are required!")
            return redirect("ps:course_master")

        # Get or create related objects
        def get_or_create_model(Model, field, value):
            return Model.objects.get_or_create(**{field: value})[0]

        course_obj = get_or_create_model(Course, "name", course_input)
        year_obj = get_or_create_model(Year, "year", year_input)
        semester_obj = get_or_create_model(Semester, "semester", semester_input)

        subject_obj, created = Subject.objects.get_or_create(
            name=subject_input,
            defaults={
                'type': coursetype_input,  # Save the course type entered by the user
                'year': year_input,
                'course': course_input,
                'semester': semester_input,
                'code': course_code,
            }
        )
        if not created:
            subject_obj.type = coursetype_input  # Update subject type
            subject_obj.year = year_input
            subject_obj.course = course_input
            subject_obj.semester = semester_input
            subject_obj.code = course_code
            subject_obj.save()

        # Determine calculation mode
        calc_mode_input = request.POST.get("calculation_mode", "Unknown")
        calculation_mode = {"1": "Average", "2": "Best of"}.get(calc_mode_input, "Unknown")

        computation_marks = (activities * max_marks) if calculation_mode == "Average" else (activities * max_marks) // 100
        co_marks = (co_attainment_activities * max_marks) if calculation_mode == "Average" else (co_attainment_activities * max_marks) // 100

        # Handle actions
        if action == "Save":
            CourseMaster.objects.create(
                academic_year=academic_year,
                course=course_obj,
                subject=subject_obj,
                year=year_obj,
                semester=semester_obj,
                course_type=coursetype_obj,  # Save course type object
                course_option=course_option,
                course_code=course_code,
                internal_exam_marks=internal_exam_marks,
                end_exam_marks=end_exam_marks,
                activities=activities,
                max_marks=max_marks,
                co_attainment_activities=co_attainment_activities,
                calculation_mode=calculation_mode,
                computation_marks=computation_marks,
                co_marks=co_marks,
                base_line_marks=base_line_marks,
                round_up=round_up,
            )
            messages.success(request, "Course details saved successfully!")

        elif action == "Edit":
            course_record = get_object_or_404(CourseMaster, recid=record_recid)
            course_record.academic_year = academic_year
            course_record.course = course_obj
            course_record.subject = subject_obj
            course_record.year = year_obj
            course_record.semester = semester_obj
            course_record.course_type = coursetype_obj  # Save course type object
            course_record.course_option = course_option
            course_record.course_code = course_code
            course_record.internal_exam_marks = internal_exam_marks
            course_record.end_exam_marks = end_exam_marks
            course_record.activities = activities
            course_record.max_marks = max_marks
            course_record.co_attainment_activities = co_attainment_activities
            course_record.calculation_mode = calculation_mode
            course_record.computation_marks = computation_marks
            course_record.co_marks = co_marks
            course_record.base_line_marks = base_line_marks
            course_record.round_up = round_up
            course_record.save()
            messages.success(request, "Course details updated successfully!")

        elif action == "Delete":
            course_record = get_object_or_404(CourseMaster, recid=record_recid)
            subject_record = course_record.subject
            course_record.delete()
            if subject_record:
                subject_record.delete()
            messages.success(request, "Course and associated subject details deleted successfully!")

        return redirect("ps:course_master")

    return render(request, "course_master.html", {
        'assessments': assessments,
        'course_master': course_master_list,
        'course_types': course_types,  # Send course types to the template
    })


from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import StudentExamInfo, Course, Year  # Import the models

def roll_update(request):
    # Get the selected academic year from the session
    academic_year = request.session.get('academic_year', 'Not Selected')

    # Get all programs and classes for dropdowns
    courses = Course.objects.all()  # Renamed variable to avoid shadowing the model name
    years = Year.objects.all()      # Renamed variable

    # Get the selected program and class from GET parameters
    selected_course = request.GET.get('course')
    selected_year = request.GET.get('year')

    # Get all students initially
    students = StudentExamInfo.objects.all()

    # Filter students based on selected program and class
    if selected_course:
        students = students.filter(Course_id=selected_course)

    if selected_year:
        students = students.filter(Year_id=selected_year)

    # Handle the action (Edit/Delete) through POST request
    if request.method == 'POST':
        action = request.POST.get('action')
        student_id = request.POST.get('student_id')

        if action == 'edit':
            # Redirect to edit the student (You can update the student info if needed)
            student = get_object_or_404(StudentExamInfo, id=student_id)
            return render(request, 'pharmacy/edit_student.html', {'student': student})

        if action == 'delete':
            # Delete the student and show a success message
            student = get_object_or_404(StudentExamInfo, id=student_id)
            student.delete()
            messages.success(request, "Student deleted successfully!")
            return redirect('roll_update')  # Redirect back to the roll_update page

    # Send context to the template
    context = {
        'academic_year': academic_year, 
        "courses": courses,
        "years": years,
        'students': students,
        'selected_course': selected_course,
        'selected_year': selected_year,
    }

    return render(request, 'roll_update.html', context)


from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import CourseOutcome, Subject



@login_required
def co_statement(request):
    academic_year = request.session.get('academic_year', 'Not Selected')

    # Retrieve subject identifier from GET or session.
    subject_id = request.GET.get('subject_id') or request.session.get('selected_subject_id')
    if not subject_id:
        messages.error(request, "No subject selected. Please select a subject first.")
        return redirect("ps:staffdashboard")
    
    # Use the subject's recid (or code) as unique identifier.
    subject = get_object_or_404(Subject, recid=subject_id)
    
    if request.method == "POST":
        action = request.POST.get("action")
        print("POST data received:", request.POST.dict())  # Debug log

        if action == "save":
            co_no = request.POST.get("co_no", "").strip()
            statement = request.POST.get("co_statement", "").strip()

            if not co_no or not statement:
                return JsonResponse({"success": False, "error": "CO Number and Statement cannot be empty."})

            # Check if CO number already exists for the subject
            if CourseOutcome.objects.filter(course_code=subject, co_id=co_no).exists():
                return JsonResponse({"success": False, "error": "CO Number already exists. Choose a different one."})

            # Limit to 5 entries per subject (optional)
            existing_count = CourseOutcome.objects.filter(course_code=subject).count()
            if existing_count >= 5:
                return JsonResponse({"success": False, "error": "Maximum of 5 CO entries allowed for this subject."})

            new_co = CourseOutcome.objects.create(
                course_code=subject,
                co_id=co_no,  # Changed from co -> co_id
                statement=statement
            )
            messages.success(request, "CO Statement saved successfully.")
            return JsonResponse({
                "success": True,
                "action": "save",
                "id": new_co.id,
                "co_no": new_co.co_id,  # Changed from co -> co_id
                "statement": new_co.statement
            })
        
        elif action == "edit":
            co_id = request.POST.get("co_id")
            co_no = request.POST.get("co_no", "").strip()
            statement = request.POST.get("co_statement", "").strip()

            if not co_no or not statement:
                return JsonResponse({"success": False, "error": "CO Number and Statement cannot be empty."})

            try:
                co_obj = CourseOutcome.objects.get(id=co_id)
                co_obj.co_id = co_no  # Changed from co -> co_id
                co_obj.statement = statement
                co_obj.save()
                messages.success(request, "CO Statement updated successfully.")
                return JsonResponse({
                    "success": True,
                    "action": "edit",
                    "id": co_obj.id,
                    "co_no": co_obj.co_id,  # Changed from co -> co_id
                    "statement": co_obj.statement
                })
            except CourseOutcome.DoesNotExist:
                return JsonResponse({"success": False, "error": "Course Outcome not found."})
            except Exception as e:
                return JsonResponse({"success": False, "error": str(e)})
        
        elif action == "delete":
            co_id = request.POST.get("co_id")
            try:
                co_obj = CourseOutcome.objects.get(id=co_id)
                co_obj.delete()
                messages.success(request, "CO Statement deleted successfully.")
                return JsonResponse({"success": True, "action": "delete", "deleted_id": co_id})
            except CourseOutcome.DoesNotExist:
                return JsonResponse({"success": False, "error": "Course Outcome not found."})
            except Exception as e:
                messages.error(request, "An error occurred while deleting the Course Outcome.")
                return JsonResponse({"success": False, "error": "An unexpected error occurred. Please try again."})

    course_outcomes = CourseOutcome.objects.filter(course_code=subject)
    return render(request, 'co_statement.html', {
        'academic_year': academic_year,
        'subject': subject,
        'course_outcomes': course_outcomes
    })


from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db import transaction
from .models import CourseOutcome, COPO_Mapping, PO, Subject
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db import transaction
from .models import CourseOutcome, COPO_Mapping, PO, Subject

def co_po_mapping(request):
    academic_year = request.session.get("academic_year", "Select Academic Year")
    subject_id = request.session.get("selected_subject_id")

    if not subject_id:
        messages.error(request, "No subject selected. Please select a subject first.")
        return redirect("ps:staffdashboard")

    subject = get_object_or_404(Subject, recid=subject_id)

    if request.method == "POST":
        co_numbers = request.POST.getlist("co_number[]")

        if not co_numbers:
            messages.error(request, "No CO data received. Please try again.")
            return redirect("ps:co_po_mapping")

        try:
            with transaction.atomic():
                for co_number in co_numbers:
                    co_id_only = co_number.split(" - ")[0]  # ✅ Extract only CO ID
                    
                    # ✅ Ensure CourseOutcome instance exists
                    co_instance = CourseOutcome.objects.filter(co_id=co_id_only, course_code=subject).first()
                    
                    if not co_instance:
                        messages.error(request, f"Error: CO '{co_id_only}' not found for this subject.")
                        return redirect("ps:co_po_mapping")

                    po_values = request.POST.getlist(f"po_values_{co_number}[]")

                    # ✅ Ensure 11 PO values (fill missing with "-")
                    while len(po_values) < 11:
                        po_values.append("-")

                    copo_data = {"subject": subject, "co_number": co_instance}

                    for i in range(11):
                        value = po_values[i].strip()

                        if value in ["High", "Medium", "Low"]:
                            # ✅ Fix: Create PO instance for High/Medium/Low if missing
                            po_instance, _ = PO.objects.get_or_create(po_no=value)
                            copo_data[f"po{i+1}"] = po_instance
                        else:
                            copo_data[f"po{i+1}"] = None

                    # ✅ Save COPO Mapping
                    COPO_Mapping.objects.update_or_create(
                        subject=subject,
                        co_number=co_instance,
                        defaults=copo_data
                    )

            messages.success(request, "CO-PO Mapping saved successfully.")
        except Exception as e:
            messages.error(request, f"An error occurred: {str(e)}")
        return redirect("ps:co_po_mapping")

    # ✅ Ensure all COs appear in the CO-PO Mapping Table
    existing_cos = set(COPO_Mapping.objects.filter(subject=subject).values_list('co_number__co_id', flat=True))
    all_cos = CourseOutcome.objects.filter(course_code=subject)

    for co in all_cos:
        if co.co_id not in existing_cos:
            COPO_Mapping.objects.create(subject=subject, co_number=co)

    mappings = COPO_Mapping.objects.filter(subject=subject).select_related('co_number')

    for mapping in mappings:
        mapping.po_values = [
            mapping.po1.po_no if mapping.po1 else "-",
            mapping.po2.po_no if mapping.po2 else "-",
            mapping.po3.po_no if mapping.po3 else "-",
            mapping.po4.po_no if mapping.po4 else "-",
            mapping.po5.po_no if mapping.po5 else "-",
            mapping.po6.po_no if mapping.po6 else "-",
            mapping.po7.po_no if mapping.po7 else "-",
            mapping.po8.po_no if mapping.po8 else "-",
            mapping.po9.po_no if mapping.po9 else "-",
            mapping.po10.po_no if mapping.po10 else "-",
            mapping.po11.po_no if mapping.po11 else "-"
        ]

    return render(request, "co_po_mapping.html", {
        "academic_year": academic_year,
        "subject": subject,
        "mappings": mappings
    })



from django.shortcuts import render, redirect, get_object_or_404
from django.utils.timezone import now
from django.http import JsonResponse
from django.contrib import messages
from django.db import transaction
from django.core.paginator import Paginator
from django.db.models import Sum
from datetime import datetime

# IMPORTANT: Import the Instruction model from your models file!
from .models import Student, Attendance, Subject, Assessment, Question, MarkEntry, Instruction
from .forms import QuestionForm # Ensure these forms exist

# ----------------------------------------------------------------
# 1. Class Attendance View
# ----------------------------------------------------------------
from django.shortcuts import render, redirect
from django.utils.timezone import now
from datetime import datetime
from .models import Subject, Attendance, Student

def class_attendance(request):
    subject_id = request.session.get("selected_subject_id")
    date_str = request.GET.get("date", now().date().strftime("%Y-%m-%d"))
    time_str = request.GET.get("time")

    # Fetch all subjects for selection
    subjects = Subject.objects.all()

    # Ensure the subject exists
    subject = Subject.objects.filter(recid=subject_id).first() if subject_id else None

    # Get distinct attendance times
    available_times = Attendance.objects.values_list("time", flat=True).distinct()

    if not subject:
        return render(request, "staffdashboard.html", {"subjects": subjects})

    # Fetch all students related to the selected subject via Assessments
    total_students = Student.objects.filter(assessment__subject=subject)

    # Default: All students are present
    present_students = list(total_students)
    absent_students = []

    if subject_id and date_str and time_str:
        try:
            date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
            time_obj = datetime.strptime(time_str, "%H:%M").time()

            # Fetch attendance records for the selected subject, date, and time
            attendance_records = Attendance.objects.filter(
                assessment__subject=subject, date=date_obj, time=time_obj
            )

            if attendance_records.exists():
                # Absent students are those marked as `is_present=False`
                absent_students = [
                    record.student for record in attendance_records if not record.is_present
                ]
                # Present students are the difference between total and absent students
                present_students = [
                    student for student in total_students if student not in absent_students
                ]

        except ValueError:
            return render(request, "attendance.html", {
                "error_message": "Invalid date or time format",
                "subjects": subjects,
                "selected_subject_id": subject_id,
            })

    return render(request, "attendance.html", {
        "subjects": subjects,
        "subject": subject,
        "available_times": available_times,
        "selected_subject_id": subject_id,
        "selected_date": date_str,
        "selected_time": time_str,
        "total_students": total_students,
        "present_students": present_students,
        "absent_students": absent_students,
    })


# ----------------------------------------------------------------
# 2. Save Attendance View
# ----------------------------------------------------------------
def save_attendance(request):
    """
    Save attendance data.
    Expects POST data with:
      - date (YYYY-MM-DD)
      - selected_time (HH:MM)
      - subject_id (subject recid)
      - absent_students[] (list of student IDs that are absent)
    """
    if request.method == "POST":
        date_str = request.POST.get("date")
        time_str = request.POST.get("selected_time")
        subject_id = request.POST.get("subject_id")
        absent_students = request.POST.getlist("absent_students[]")  # list of absent student IDs

        # Validate required fields
        if not date_str or not time_str or not subject_id:
            return JsonResponse({"message": "Missing required fields!"}, status=400)
        try:
            date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
            time_obj = datetime.strptime(time_str, "%H:%M").time()
        except ValueError:
            return JsonResponse({"message": "Invalid date or time format!"}, status=400)

        # Get the subject (using recid as primary key)
        subject = get_object_or_404(Subject, recid=subject_id)

        # Get all students associated with this subject.
        # Adjust the filter as per your model relationships.
        students = Student.objects.filter(assessment__subject=subject).distinct()

        # Loop through students: if a student’s id is in absent_students, mark absent; otherwise mark present.
        for student in students:
            is_present = str(student.id) not in absent_students
            # Use update_or_create to create or update the attendance record.
            # Adjust the filter parameters (assessment, etc.) as needed.
            Attendance.objects.update_or_create(
                student=student,
                subject=subject,
                date=date_obj,
                time=time_obj,
                defaults={"is_present": is_present, "attendance_type": "class"},
            )
        return JsonResponse({"message": "Attendance saved successfully!"})
    return JsonResponse({"message": "Invalid request method."}, status=405)




# ----------------------------------------------------------------
# 3. Update Attendance View
# ----------------------------------------------------------------
def update_attendance(request):
    if request.method == "POST":
        student_id = request.POST.get("student_id")
        assessment_id = request.POST.get("assessment_id")
        selected_date = request.POST.get("date")  # YYYY-MM-DD
        selected_time = request.POST.get("time")   # HH:MM:SS
        is_present = request.POST.get("is_present") == "true"

        if not student_id or not selected_date or not selected_time:
            return JsonResponse({"status": "error", "message": "Missing data!"}, status=400)

        student = get_object_or_404(Student, id=student_id)

        # Convert date and time
        date_obj = datetime.strptime(selected_date, "%Y-%m-%d").date()
        time_obj = datetime.strptime(selected_time, "%H:%M:%S").time()

        attendance, created = Attendance.objects.get_or_create(
            student=student,
            assessment_id=assessment_id,
            date=date_obj,
            time=time_obj,
        )

        # Update attendance status
        attendance.is_present = is_present
        attendance.save()

        return JsonResponse({"status": "success", "is_present": attendance.is_present})

    return JsonResponse({"status": "error"}, status=400)


# ----------------------------------------------------------------
# 4. Attendance Report View
# ----------------------------------------------------------------
from django.shortcuts import render
from django.db.models import Count, Sum, Q
from .models import Attendance, Student
from django.shortcuts import render
from django.db.models import Count, Q
from .models import Attendance, Student

def attendance_report(request):
    start_date = request.GET.get('date', '2025-03-31')
    subject_id = request.GET.get('subject', 1)

    attendance_data = Student.objects.annotate(
        TL=Count('attendance', filter=Q(attendance__date=start_date)),
        TA=Count('attendance', filter=Q(attendance__date=start_date, attendance__is_present=False)),
        TP=Count('attendance', filter=Q(attendance__date=start_date, attendance__is_present=True)),
        Attendance_Percentage=100.0 * Count('attendance', filter=Q(attendance__date=start_date, attendance__is_present=True)) / 
                               Count('attendance', filter=Q(attendance__date=start_date))
    ).values('id', 'prn', 'name', 'TL', 'TA', 'TP', 'Attendance_Percentage')  # Changed 'registration_number' to 'prn'

    context = {
        'attendance_data': attendance_data,
        'start_date': start_date,
        'subject_id': subject_id
    }
    return render(request, 'attendance_report.html', context)




# ----------------------------------------------------------------
# 5. Mark Entry View
# ----------------------------------------------------------------
from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.db.models import Sum
from django.core.paginator import Paginator
from django.contrib import messages
from django.http import JsonResponse
import logging

logger = logging.getLogger(__name__)

# Import your models here.
from .models import Assessment, Student, Attendance, Subject, Question, MarkEntry

def is_ajax(request):
    """Return True if the request is an AJAX request."""
    return request.headers.get('x-requested-with') == 'XMLHttpRequest'

def mark_entry(request, recid=None):
    assessments = Assessment.objects.all()
    students = Student.objects.all()
    selected_assessment = None
    attendance_records = []
    total_students = students.count()

    present_count = 0
    absent_count = 0
    total_present = 0
    total_absent = 0
    total_marks = 0
    total_marks_for_subject = 0
    total_exams = 0
    assessment_totals = None
    current_student = None
    subject = None
    page_obj = None
    questions = None
    mark_entries = None
    present_students = None

    # Get the active tab parameter, default to 'attendance'
    active_tab = request.GET.get("active_tab", "attendance")

    if recid:
        selected_assessment = get_object_or_404(Assessment, recid=recid)

        # Ensure one attendance record per student for the selected assessment
        for student in students:
            duplicates = Attendance.objects.filter(assessment=selected_assessment, student=student)
            if duplicates.count() > 1:
                duplicates.exclude(id=duplicates.first().id).delete()  # Keep only the first record
            Attendance.objects.get_or_create(
                assessment=selected_assessment, student=student, defaults={"is_present": False}
            )

        # Process POST requests
        if request.method == "POST":
            form_type = request.POST.get("form_type")

            # -----------------------------
            # 1. ATTENDANCE FORM SUBMISSION
            # -----------------------------
            if form_type == "attendance":
                if "mark_all_present" in request.POST:
                    Attendance.objects.filter(assessment=selected_assessment).update(is_present=True)
                else:
                    present_students_ids = [
                        int(key.split("_")[1])
                        for key in request.POST if key.startswith("present_")
                    ]
                    for student in students:
                        attendance = Attendance.objects.filter(
                            assessment=selected_assessment, student=student
                        ).first()
                        if attendance:
                            attendance.is_present = (student.id in present_students_ids)
                            attendance.save()
                return redirect("ps:merged_mark_entry", recid=recid)

            # -----------------------------
            # 2. MARK ENTRY FORM SUBMISSION
            # -----------------------------
            # We postpone processing until after we prepare the mark_entries below.

        # Set up required data for both GET and mark entry processing

        attendance_records = Attendance.objects.filter(assessment=selected_assessment).select_related("student")
        present_count = attendance_records.filter(is_present=True).count()
        absent_count = total_students - present_count

        # Instead of looking up Subject by code, we assume Assessment has a foreign key to Subject.
        # If your model does not have this, adjust accordingly.
        subject = selected_assessment.subject  
        # Alternatively, if you must look up by code and you're sure of your data:
        # subject = get_object_or_404(Subject, code=selected_assessment.code)

        present_students = Student.objects.filter(
            attendance__assessment=selected_assessment,
            attendance__is_present=True
        ).distinct()
        total_present = present_students.count()
        total_absent = total_students - total_present

        paginator = Paginator(present_students, 1)  # One student per page for mark entry
        page_number = request.GET.get("page", 1)
        page_obj = paginator.get_page(page_number)
        current_student = page_obj.object_list[0] if page_obj else None

        questions = Question.objects.filter(subject=subject, assessment=selected_assessment)

        # Create missing MarkEntry records for the current student
        if current_student:
            with transaction.atomic():
                mark_entries_to_create = []
                for question in questions:
                    if not MarkEntry.objects.filter(
                        student=current_student,
                        subject=subject,
                        assessment=selected_assessment,
                        question=question
                    ).exists():
                        mark_entries_to_create.append(
                            MarkEntry(
                                student=current_student,
                                subject=subject,
                                assessment=selected_assessment,
                                question=question,
                                obtained_marks=0
                            )
                        )
                if mark_entries_to_create:
                    MarkEntry.objects.bulk_create(mark_entries_to_create)

        mark_entries = MarkEntry.objects.filter(
            student=current_student,
            assessment=selected_assessment,
            subject=subject
        ).select_related("question").order_by("question__quiz_no")

        # Now process the mark entry form submission if applicable.
        if request.method == "POST" and request.POST.get("form_type") == "mark_entry":
            updated = False
            with transaction.atomic():
                for entry in mark_entries:
                    marks_key = f"marks_{entry.id}"
                    if marks_key in request.POST:
                        value = request.POST.get(marks_key, "").strip()
                        logger.debug(f"Processing {marks_key} with value '{value}' for Question {entry.question.quiz_no}")
                        try:
                            obtained_marks = int(value) if value != "" else 0
                            if entry.obtained_marks != obtained_marks:
                                entry.obtained_marks = obtained_marks
                                entry.save()
                                updated = True
                                logger.debug(f"Updated marks for Question {entry.question.quiz_no} to {obtained_marks}")
                        except ValueError:
                            logger.error(f"Invalid input for marks in Question {entry.question.quiz_no}: {value}", exc_info=True)
                            messages.error(request, f"Invalid input for Question {entry.question.quiz_no}")

            total_marks = MarkEntry.objects.filter(
                student=current_student,
                assessment=selected_assessment
            ).aggregate(Sum("obtained_marks"))["obtained_marks__sum"] or 0
            current_student.total_marks = total_marks
            current_student.save()
            logger.debug(f"Total marks for student {current_student.id} updated to {total_marks}")

            if is_ajax(request):
                return JsonResponse({
                    "status": "success",
                    "message": "Marks saved successfully!" if updated else "No changes were made.",
                    "total_marks": total_marks
                })
            else:
                if updated:
                    messages.success(request, f"Marks saved successfully for {selected_assessment.assessment_type}!")
                else:
                    messages.info(request, "No changes made to marks.")
                return redirect(f"{request.path}?page={page_number}&active_tab=mark_entry")

        # Compute additional totals for display
        if current_student:
            total_marks = MarkEntry.objects.filter(
                student=current_student,
                assessment=selected_assessment
            ).aggregate(Sum("obtained_marks"))["obtained_marks__sum"] or 0

        total_marks_for_subject = MarkEntry.objects.filter(
            subject=subject,
            assessment=selected_assessment
        ).aggregate(Sum("obtained_marks"))["obtained_marks__sum"] or 0

        total_exams = Assessment.objects.filter(markentry__isnull=False).distinct().count()

        assessment_totals = MarkEntry.objects.filter(
            student__in=present_students
        ).values("student__id", "assessment__assessment_type").annotate(
            total_marks=Sum("obtained_marks")
        )

    context = {
        "assessments": assessments,
        "students": students,
        "selected_assessment": selected_assessment,
        "attendance_records": attendance_records,
        "total_students": total_students,
        "present_count": present_count,
        "absent_count": absent_count,
        "subject": subject if recid else None,
        "current_student": current_student,
        "questions": questions,
        "mark_entries": mark_entries,
        "page_obj": page_obj,
        "present_students": present_students,
        "total_present": total_present,
        "total_absent": total_absent,
        "total_marks": total_marks,
        "total_marks_for_subject": total_marks_for_subject,
        "total_exams": total_exams,
        "assessment_totals": assessment_totals,
        "active_tab": active_tab,
    }
    return render(request, "mark_entry.html", context)



# ----------------------------------------------------------------
# 6. Assessment View
# ----------------------------------------------------------------
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .forms import AssessmentForm
from .models import CO, PO, Assessment, Instruction, Question, Subject
def assessment_view(request):
    form = AssessmentForm()
    assessment_data = None
    show_instruction_navbar = False
    instructions = Instruction.objects.all()
    selected_instructions = []
    selected_question = None
    questions = Question.objects.all()

    academic_year = request.session.get("academic_year", "Select Academic Year")
    subject_id = request.session.get("selected_subject_id")
    if not subject_id:
        messages.error(request, "No subject selected. Please select a subject first.")
        return redirect("ps:staffdashboard")
    subject = get_object_or_404(Subject, recid=subject_id)

    # If an assessment was previously saved, load it from the session.
    assessment_id = request.session.get("assessment_id")
    if assessment_id:
        assessment_data = Assessment.objects.filter(id=assessment_id).first()

    if request.method == "POST":
        form_type = request.POST.get("form_type")
        
        if form_type == "instruction":
            # Process Instruction Form
            selected_instruction_ids = request.POST.getlist("selected_instructions")
            custom_instruction = request.POST.get("custom_instruction", "").strip()
            if custom_instruction:
                new_instruction = Instruction.objects.create(text=custom_instruction)
                selected_instruction_ids.append(new_instruction.id)
                messages.success(request, "Custom instruction added successfully.")
            if selected_instruction_ids:
                request.session["selected_instructions"] = selected_instruction_ids
                request.session.modified = True
                messages.success(request, "Selected instructions saved successfully.")
            else:
                messages.warning(request, "No instructions selected. Please select at least one.")

        elif form_type == "assessment":
            # Process Assessment Form
            form = AssessmentForm(request.POST)
            if form.is_valid():
                assessment_instance = form.save(commit=False)
                assessment_instance.subject = subject  # Associate subject with assessment
                assessment_instance.save()
                assessment_data = assessment_instance
                # Store the assessment id in the session for later use in question creation
                request.session["assessment_id"] = assessment_instance.id
                messages.success(request, "Assessment saved successfully.")
                show_instruction_navbar = True
            else:
                print("Assessment Form Errors:", form.errors)  # Debug output
                messages.error(request, "Error saving assessment. Please check the form.")

        elif form_type == "question_setting":
            # Process Question Setting Form
            question_id = request.POST.get("question_id")
            section = request.POST.get("section")
            que_tag = request.POST.get("que_tag")
            question_text = request.POST.get("question_text")
            quiz_no = request.POST.get("quiz_no")
            attempt_any = request.POST.get("attempt_any")
            sub_que_no = request.POST.get("sub_que_no")
            marks = request.POST.get("marks")
            co_id = request.POST.get("co")
            po_id = request.POST.get("po")
            # Retrieve assessment_type from POST data
            assessment_type_id = request.POST.get("assessment_type")
            if not assessment_type_id:
                messages.error(request, "Assessment Type is required for question setting.")
            else:
                # Ensure assessment_data is available (try to retrieve from session if not in local variable)
                if not assessment_data:
                    assessment_id = request.session.get("assessment_id")
                    if assessment_id:
                        assessment_data = Assessment.objects.filter(id=assessment_id).first()
                if not assessment_data:
                    messages.error(request, "Please save an assessment before adding a question.")
                else:
                    if question_id:
                        # Update existing question
                        question = get_object_or_404(Question, id=question_id)
                        question.section = section
                        question.que_tag = que_tag
                        question.question_text = question_text
                        question.quiz_no = quiz_no
                        question.attempt_any = attempt_any
                        question.sub_que_no = sub_que_no
                        question.marks = marks
                        if co_id:
                            question.co_id = co_id
                        if po_id:
                            question.po_id = po_id
                        question.assessment_type_id = assessment_type_id
                        question.save()
                        messages.success(request, "Question updated successfully.")
                    else:
                        # Create a new question
                        Question.objects.create(
                            assessment_type_id=assessment_type_id,
                            assessment=assessment_data,
                            subject=subject,
                            section=section,
                            que_tag=que_tag,
                            question_text=question_text,
                            quiz_no=quiz_no,
                            attempt_any=attempt_any,
                            sub_que_no=sub_que_no,
                            marks=marks,
                            co_id=co_id if co_id else None,
                            po_id=po_id if po_id else None,
                        )
                        messages.success(request, "Question saved successfully.")

        elif "assessment_type" in request.POST:
            # This block seems to be for fetching an existing assessment by type.
            form = AssessmentForm(request.POST)
            assessment_type_id = request.POST.get("assessment_type")
            assessment_data = Assessment.objects.filter(assessment_type_id=assessment_type_id).first()
            if assessment_data:
                form = AssessmentForm(instance=assessment_data)
                show_instruction_navbar = True

    selected_instruction_ids = request.session.get("selected_instructions", [])
    if selected_instruction_ids:
        selected_instructions = Instruction.objects.filter(id__in=selected_instruction_ids)

    selected_question_id = request.GET.get("question_id")
    if selected_question_id:
        selected_question = get_object_or_404(Question, id=selected_question_id)

    co_list = CO.objects.all()
    po_list = PO.objects.all()

    return render(
        request,
        "assessment.html",
        {
            "form": form,
            "assessment_data": assessment_data,
            "academic_year": academic_year,
            "subject": subject,
            "show_instruction_navbar": show_instruction_navbar,
            "instructions": instructions,
            "selected_instructions": selected_instructions,
            "questions": questions,
            "selected_question": selected_question,
            "co_list": co_list,
            "po_list": po_list,
        },
    )

    
    
# ----------------------------------------------------------------
# 7. User Logout View
# ----------------------------------------------------------------
def user_logout(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("ps:login")


from django.db.models import Sum, Value
from django.db.models.functions import Coalesce
def course_marks(request):
    if request.method == "POST" and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        # Retrieve subject_id from POST data, falling back to the session.
        subject_id = request.POST.get("subject_id") or request.session.get("selected_subject_id")
        if not subject_id:
            return JsonResponse({"success": False, "message": "Subject ID is required."})
        
        try:
            # Retrieve students associated with the subject via the assessment relationship.
            # Note: Use subject__recid lookup since Subject's primary key is recid.
            students = Student.objects.filter(assessment__subject__recid=subject_id).distinct()
            marks_data = []
            
            for student in students:
                # Retrieve marks for each student and group them by exam_type.
                # Use subject__recid lookup here as well.
                marks = MarkEntry.objects.filter(
                    student=student,
                    subject__recid=subject_id
                ).values('exam_type').annotate(
                    total_marks=Coalesce(Sum('obtained_marks'), Value(0))
                )
                
                # Initialize student data with placeholders for each exam category.
                student_data = {
                    "roll_no": student.roll_no,
                    "name": student.name,
                    "Sessional": 0,  # Sessional (CA-1 + CA-2)
                    "Internal": 0,   # Internal (IE-1 + IE-2)
                    "External": 0,   # External (Ext-1 to Ext-4), if applicable
                    "total_marks": 0
                }
                
                total = 0  # Compute total marks
                
                for mark in marks:
                    exam_type = mark['exam_type']
                    if exam_type == 'session':
                        student_data['Sessional'] = mark['total_marks']
                    elif exam_type == 'internal':
                        student_data['Internal'] = mark['total_marks']
                    # You can add additional exam types (like 'external') if needed.
                    total += mark['total_marks']
                
                student_data['total_marks'] = total
                marks_data.append(student_data)
            
            return JsonResponse({"success": True, "marks_data": marks_data})
        
        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)})
    
    else:
        # GET request: Retrieve all subjects and, if available, the selected subject from session.
        subjects = Subject.objects.all()
        subject_id = request.session.get("selected_subject_id")
        # Use recid for lookup here
        subject = get_object_or_404(Subject, recid=subject_id) if subject_id else None
        return render(request, 'course_marks.html', {"subjects": subjects, "subject": subject})


def co_tools(request):
    subject_id = request.session.get("selected_subject_id")
    if not subject_id:
        return render(request, "co_tools.html", {"error": "No subject selected!"})

    # Attempt to fetch an assessment associated with this subject.
    assessment = Assessment.objects.filter(subject__recid=subject_id).first()

    # If an assessment exists, use its subject; otherwise, retrieve the subject directly.
    if assessment:
        subject = assessment.subject
    else:
        subject = Subject.objects.filter(recid=subject_id).first()

    if not subject:
        return render(request, "co_tools.html", {"error": "No subject found!"})

    # Retrieve students, questions, and marks data for the subject using recid.
    students = Student.objects.filter(assessment__subject__recid=subject_id)
    questions = Question.objects.filter(subject__recid=subject_id)
    marks_data = MarkEntry.objects.filter(subject__recid=subject_id)

    # Calculate the maximum possible marks.
    max_marks = sum(q.marks if q.marks is not None else 0 for q in questions) if questions else 1

    # Calculate each student's total marks, percentage, and assign a level.
    for student in students:
        student.total_marks = sum(
            mark.obtained_marks if mark.obtained_marks is not None else 0
            for mark in marks_data if mark.student_id == student.id
        )
        student.percentage = (student.total_marks / max_marks) * 100 if max_marks > 0 else 0

        if student.percentage >= 80:
            student.level = 5
        elif student.percentage >= 60:
            student.level = 4
        elif student.percentage >= 40:
            student.level = 3
        elif student.percentage >= 20:
            student.level = 2
        else:
            student.level = 1

    # --- Additional Logic Starts Here ---
    # Sort students by descending percentage.
    students = sorted(students, key=lambda s: s.percentage, reverse=True)

    if students:
        avg_percentage = sum(student.percentage for student in students) / len(students)
        top_student = max(students, key=lambda s: s.percentage)
        bottom_student = min(students, key=lambda s: s.percentage)
    else:
        avg_percentage = 0
        top_student = None
        bottom_student = None
    # --- Additional Logic Ends Here ---

    # Build a dictionary with subject details retrieved from the subject object.
    subject_details = {
        "program": subject.course,
        "year": subject.year,
        "semester": subject.semester,
        "course_code": subject.code,
        "course_name": subject.name,
    }

    context = {
        "subject": subject,
        "subject_details": subject_details,
        "students": students,
        "questions": questions,
        "marks_data": marks_data,
        "max_marks": max_marks,
        "avg_percentage": avg_percentage,
        "top_student": top_student,
        "bottom_student": bottom_student,
    }
    return render(request, "co_tools.html", context)
from django.shortcuts import render, get_object_or_404
from .models import Subject, Assessment, Question, MarkEntry

def determine_attainment_level(percentage):
    if percentage >= 80:
        return 3
    elif percentage >= 60:
        return 2
    elif percentage >= 40:
        return 1
    else:
        return 0

def co_attainment_analysis(request):
    # Retrieve selected subject from session
    subject_id = request.session.get("selected_subject_id")
    if not subject_id:
        return render(request, 'co_attainment_analysis.html', {
            'error': 'Please select a subject from the home page.'
        })

    # Use recid for lookup instead of id
    subject = get_object_or_404(Subject, recid=subject_id)

    # Get related assessments and questions
    assessments = Assessment.objects.filter(subject=subject)
    questions = Question.objects.filter(assessment__in=assessments)

    # Get unique COs from questions
    co_list = questions.values_list('co_id', flat=True).distinct()

    # Get selected CO from request
    selected_co = request.GET.get("selected_co")
    if selected_co:
        questions = questions.filter(co_id=selected_co)  # Filter questions for selected CO

    mark_entries = MarkEntry.objects.filter(assessment__in=assessments)

    # Initialize CO data
    co_data = {}
    for question in questions:
        co_code = question.co_id
        if co_code not in co_data:
            co_data[co_code] = {
                'total_marks': 0,
                'obtained_marks': 0,
                'students': 0
            }
        # Filter marks for this specific question
        entries = mark_entries.filter(assessment=question.assessment, question=question)
        for entry in entries:
            if entry.obtained_marks is not None:
                co_data[co_code]['obtained_marks'] += entry.obtained_marks
                co_data[co_code]['total_marks'] += question.marks
                co_data[co_code]['students'] += 1

    # Compute Percentage and Attainment Level for each CO
    internal_weighted_contribution = 0
    external_weighted_contribution = 0
    for co, data in co_data.items():
        data['percentage'] = round((data['obtained_marks'] / data['total_marks']) * 100, 2) if data['total_marks'] else 0
        data['level'] = determine_attainment_level(data['percentage'])
        # Contribution Calculation
        internal_weighted_contribution += data['percentage'] * 0.4
        external_weighted_contribution += data['percentage'] * 0.6

    # Overall CO Attainment
    total_attainment = (internal_weighted_contribution + external_weighted_contribution) / len(co_data) if co_data else 0

    # Define CO Target
    co_target = 75  # Modify if needed
    target_achieved = "Yes" if total_attainment >= co_target else "No"

    return render(request, 'co_attainment_analysis.html', {
        'subject': subject,
        'co_list': co_list,
        'selected_co': selected_co,
        'co_data': co_data,
        'internal_weighted_contribution': internal_weighted_contribution,
        'external_weighted_contribution': external_weighted_contribution,
        'total_attainment': total_attainment,
        'co_target': co_target,
        'target_achieved': target_achieved,
    })


def determine_attainment_level(percentage):
    if percentage >= 75:
        return "Level 3"
    elif percentage >= 50:
        return "Level 2"
    else:
        return "Level 1"

def course_summary(request):
    # Retrieve the selected subject from the session
    subject_id = request.session.get("selected_subject_id")
    selected_subject = None

    if subject_id:
        try:
            selected_subject = Subject.objects.get(recid=subject_id)
        except Subject.DoesNotExist:
            selected_subject = None

    # If needed, fetch all subjects for a dropdown or other logic
    subjects = Subject.objects.all()

    context = {
        "selected_subject": selected_subject,
        "subjects": subjects,
    }
    return render(request, "course_summary.html", context)

def print_preview(request):
    questions = Question.objects.all()  # Adjust this query as needed
    
    # Fetch an assessment if available
    assessment = Assessment.objects.first()  # Replace this logic as needed

    context = {'questions': questions, 'assessment': assessment}
    
    return render(request, 'print_preview.html', context)


def question_paper(request, assessment_id):
    assessment = get_object_or_404(Assessment, id=assessment_id)
    
    # Get all questions linked to this assessment
    questions = Question.objects.filter(assessment=assessment).order_by('quiz_no', 'sub_que_no')

    # Get the subject associated with the assessment (assuming all questions belong to one subject)
    subject = questions.first().subject if questions.exists() else None  # Handles case where no questions exist

    if request.method == "POST":
        # Process the form and generate the question paper dynamically

        # Example logic: Filter questions based on submitted parameters
        quiz_no_filter = request.POST.get("quiz_no", None)
        marks_filter = request.POST.get("marks", None)

        if quiz_no_filter:
            questions = questions.filter(quiz_no=quiz_no_filter)

        if marks_filter:
            questions = questions.filter(marks=marks_filter)

        # You can add more filtering logic as required based on form data

    context = {
        "assessment": assessment,
        "questions": questions,
        "subject": subject  # Pass subject to template
    }
    return render(request, "question_paper.html", context)

def print_preview_view(request, rec_id):
    assessment = get_object_or_404(Assessment, id=rec_id)

    # Use a dictionary to store unique student records
    student_map = {}

    # Get all mark entries for this assessment
    mark_entries = MarkEntry.objects.filter(assessment=assessment)

    for mark in mark_entries:
        student = mark.student

        if student.id not in student_map:
            student_map[student.id] = {
                'roll_no': student.roll_no,
                'assessment_type': assessment.assessment_type,  # Add assessment type
                'mark_entries': [],
                'total_marks': 0  # Correct field name
            }

        # Get max_marks from the related Question model
        max_marks = mark.question.marks if mark.question else 0

        student_map[student.id]['mark_entries'].append({
            'obtained_marks': mark.obtained_marks,
            'max_marks': max_marks
        })
        student_map[student.id]['total_marks'] += mark.obtained_marks or 0  # Corrected Calculation

    # Convert dictionary values to a list
    students = list(student_map.values())

    context = {
        'assessment': assessment,
        'students': students
    }
    return render(request, 'print_preview_view.html', context)


import json
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import Course, Year, Semester, Subject, FacultyCourseAllocation
from django.contrib.auth import get_user_model

CustomUser = get_user_model()

@csrf_exempt
def staff_allotment(request):
    academic_year = request.session.get('academic_year', 'Not Selected')

    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            faculty_id = data.get('faculty_id')
            subjects = data.get('subjects', [])

            # Get faculty instance
            faculty = CustomUser.objects.get(id=faculty_id)

            for sub in subjects:
                subject_id = sub.get('subject_id')

                # Fetch subject using recid instead of id
                subject_instance = Subject.objects.get(recid=subject_id)

                # Create or update faculty-course allocation
                FacultyCourseAllocation.objects.update_or_create(
                    faculty=faculty,
                    subject=subject_instance,
                    defaults={}
                )

            return JsonResponse({"success": True})
        except Subject.DoesNotExist:
            return JsonResponse({"success": False, "message": "Subject not found."})
        except CustomUser.DoesNotExist:
            return JsonResponse({"success": False, "message": "Faculty not found."})
        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)})

    # Handle GET request for AJAX subject fetching
    action = request.GET.get('action')
    if action == 'fetch_courses_by_selection':
        course_value = request.GET.get('courseId')
        year_value = request.GET.get('yearId')
        semester_value = request.GET.get('semesterId')
        subject_type = request.GET.get('subjectType', 'Theory')

        filters = {}
        if course_value:
            filters['course'] = course_value
        if year_value:
            filters['year'] = year_value
        if semester_value:
            filters['semester'] = semester_value

        subjects = Subject.objects.filter(**filters, type=subject_type).values('recid', 'code', 'name')
        return JsonResponse(list(subjects), safe=False)

    # Fetch dropdown data
    courses = Course.objects.all()
    years = Year.objects.all()
    semesters = Semester.objects.all()
    faculties = CustomUser.objects.filter(user_type='staff', is_active=True)
    allocated_courses = FacultyCourseAllocation.objects.all()

    context = {
        'academic_year': academic_year,
        'faculties': faculties,
        'courses': courses,
        'years': years,
        'semesters': semesters,
        'assigned_subjects': allocated_courses,
        'course_list': [],
    }

    return render(request, 'staff_allotment.html', context)   